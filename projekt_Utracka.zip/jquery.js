$(document).ready(function() {
    $('.main_img_container').cycle({
        timeout: 3000,  
        speed: 500,     
        pauseOnHover: true,
        prev: '.prev',   
        next: '.next'    
    });
});